const supabaseUrl = "https://uabehqwnelpkvskzimni.supabase.co";
const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVhYmVocXduZWxwa3Zza3ppbW5pIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk1MzI0NTgsImV4cCI6MjA2NTEwODQ1OH0.29t1bKYevEWkeiAGbiVbwgNi4QoxXNIMCkHNNga_BB0";

const { createClient } = supabase;
const supabaseClient = createClient(supabaseUrl, supabaseKey); // ✅ Match variable names

(async () => {
  const { data: { session } } = await supabaseClient.auth.getSession();

  if (!session) {
    window.location.href = '/team/login/';
    return;
  }

  const { data: teamData } = await supabaseClient
    .from('team')
    .select('user_id')
    .eq('user_id', session.user.id)
    .single();

  if (!teamData) {
    await supabaseClient.auth.signOut();
    window.location.href = '/team/login/';
  }

  document.body.style.visibility = 'visible';
})();

document.body.style.visibility = 'hidden';
