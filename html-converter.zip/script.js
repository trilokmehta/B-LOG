document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Elements ---
    const docxFileInput = document.getElementById('docx-file');
    const fileLabel = document.querySelector('.file-label');
    const uploadPrompt = document.getElementById('upload-prompt');
    const fileNameDisplay = document.getElementById('file-name-display');
    const convertBtn = document.getElementById('convert-btn');
    const outputSection = document.getElementById('output-section');
    const htmlPreview = document.getElementById('html-preview');
    const downloadHtmlLink = document.getElementById('download-html');
    const downloadCssLink = document.getElementById('download-css');
    const downloadJsLink = document.getElementById('download-js');
    const messagesContainer = document.getElementById('messages-container');
    const conventionsLink = document.getElementById('conventions-link');
    const modal = document.getElementById('conventions-modal');
    const modalClose = document.querySelector('.modal-close');
    const modalBody = document.getElementById('modal-body');

    let selectedFile = null;

    // --- Event Listeners ---
    fileLabel.addEventListener('click', () => docxFileInput.click());
    docxFileInput.addEventListener('change', handleFileSelect);
    convertBtn.addEventListener('click', handleFileConversion);
    conventionsLink.addEventListener('click', showConventions);
    modalClose.addEventListener('click', hideConventions);
    modal.addEventListener('click', (e) => e.target === modal && hideConventions());

    // Drag and Drop functionality
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        fileLabel.addEventListener(eventName, preventDefaults, false);
    });
    ['dragenter', 'dragover'].forEach(eventName => {
        fileLabel.addEventListener(eventName, () => fileLabel.classList.add('dragover'), false);
    });
    ['dragleave', 'drop'].forEach(eventName => {
        fileLabel.addEventListener(eventName, () => fileLabel.classList.remove('dragover'), false);
    });
    fileLabel.addEventListener('drop', handleDrop, false);

    // --- Core Functions ---

    function handleFileSelect(event) {
        const files = event.target.files;
        if (files.length > 0) {
            processFile(files[0]);
        }
    }
    
    function handleDrop(event) {
        const dt = event.dataTransfer;
        const files = dt.files;
        if (files.length > 0) {
            processFile(files[0]);
        }
    }

    function processFile(file) {
        if (file && file.name.endsWith('.docx')) {
            selectedFile = file;
            uploadPrompt.style.display = 'none';
            fileNameDisplay.textContent = selectedFile.name;
            fileNameDisplay.style.display = 'block';
            convertBtn.disabled = false;
        } else {
            selectedFile = null;
            addMessage('error', 'Invalid file type. Please select a .docx file.');
            convertBtn.disabled = true;
        }
    }

    async function handleFileConversion() {
        if (!selectedFile) {
            addMessage('error', 'Please select a .docx file first.');
            return;
        }

        toggleLoader(true);
        clearMessages();
        outputSection.style.display = 'none';

        try {
            const arrayBuffer = await readFileAsArrayBuffer(selectedFile);
            const mammothResult = await mammoth.convertToHtml({ arrayBuffer });
            
            const processor = new SmartProcessor(mammothResult.value, "Examvest");
            const processedResult = processor.process();

            displayResult(processedResult);
            processedResult.messages.forEach(msg => addMessage(msg.type, msg.text, msg.icon));

        } catch (error) {
            handleError(error);
        } finally {
            toggleLoader(false);
        }
    }

    function displayResult(result) {
        const finalHtml = result.html;
        const cssContent = getBlogCssContent();
        const jsContent = getBlogJsContent();

        setupDownloadLinks(finalHtml, cssContent, jsContent);

        htmlPreview.srcdoc = finalHtml;
        outputSection.style.display = 'block';
    }

    // --- UI & Helper Functions ---

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    function toggleLoader(show) {
        const btnText = convertBtn.querySelector('.btn-text');
        const btnLoader = convertBtn.querySelector('.btn-loader');
        if (show) {
            btnText.style.display = 'none';
            btnLoader.style.display = 'inline-block';
            convertBtn.disabled = true;
        } else {
            btnText.style.display = 'inline-block';
            btnLoader.style.display = 'none';
            convertBtn.disabled = (selectedFile === null);
        }
    }

    function addMessage(type, text, icon) {
        const messageEl = document.createElement('div');
        messageEl.className = `message ${type}`;
        messageEl.innerHTML = `${icon}<span>${text}</span>`;
        messagesContainer.appendChild(messageEl);
    }

    function clearMessages() {
        messagesContainer.innerHTML = '';
    }

    function handleError(error) {
        console.error('Conversion failed:', error);
        addMessage('error', `An error occurred: ${error.message || error}`, '&#10060;'); // Cross mark
        outputSection.style.display = 'none';
    }

    function readFileAsArrayBuffer(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (event) => resolve(event.target.result);
            reader.onerror = (err) => reject('Error reading the file.', err);
            reader.readAsArrayBuffer(file);
        });
    }

    function setupDownloadLinks(htmlContent, cssContent, jsContent) {
        downloadHtmlLink.href = createBlobUrl(htmlContent, 'text/html');
        downloadCssLink.href = createBlobUrl(cssContent, 'text/css');
        downloadJsLink.href = createBlobUrl(jsContent, 'text/javascript');
    }

    function createBlobUrl(content, type) {
        const blob = new Blob([content], { type });
        return URL.createObjectURL(blob);
    }

    function showConventions(e) {
        e.preventDefault();
        modalBody.innerHTML = getConventionsContent();
        modal.classList.add('visible');
    }

    function hideConventions() {
        modal.classList.remove('visible');
    }
});

/**
 * The "Brain" of the converter.
 * Takes raw HTML from Mammoth.js and applies smart transformations based on conventions.
 */
class SmartProcessor {
    constructor(rawHtml, siteName) {
        this.doc = new DOMParser().parseFromString(rawHtml, 'text/html');
        this.siteName = siteName;
        this.metadata = {};
        this.messages = [];
        this.authorNotes = {};
    }

    process() {
        this._extractMetadata();
        this._extractAuthorNotes();
        this._processBody();
        this._cleanupHtml();
        const finalHtml = this._buildFinalHtml();
        
        return {
            html: finalHtml,
            messages: this.messages
        };
    }

    _extractMetadata() {
    // Look for the main title, which is the first H1 in the document
    const h1 = this.doc.body.querySelector('h1');
    if (h1) {
        this.metadata['title'] = h1.textContent.trim();
        // We will set the final H1 in the template, so remove this one from the body
        h1.remove(); 
        this.messages.push({ type: 'success', text: 'Title found and processed.', icon: '&#9989;' });
    }

    // Now, find the paragraph containing "Meta Description:"
    const paragraphs = Array.from(this.doc.body.querySelectorAll('p'));
    const descPara = paragraphs.find(p => p.textContent.trim().startsWith('Meta Description:'));

    if (descPara) {
        const descText = descPara.textContent.replace(/Meta Description:/i, '').trim();
        this.metadata['description'] = descText;

        // Remove the description paragraph from the document body
        descPara.remove();
        this.messages.push({ type: 'success', text: 'Meta Description found and processed.', icon: '&#9989;' });
    }

    // If after all that, we still have no title, show a warning.
    if (!this.metadata['title']) {
        this.messages.push({ type: 'warning', text: 'Could not find a title. Using defaults.', icon: '&#9888;' });
    }
}

    _extractAuthorNotes() {
        const paragraphs = Array.from(this.doc.body.querySelectorAll('p'));
        const notesKeywords = ['Primary Keyword:', 'LSI Keywords:', 'Emotional Hooks Summary:', 'AI Detection:', 'SEO Score:', 'Word Count:'];
        
        paragraphs.forEach(p => {
            const text = p.textContent.trim();
            const keyword = notesKeywords.find(k => text.startsWith(k));
            if (keyword) {
                this.authorNotes[keyword] = text.replace(keyword, '').trim();
                p.remove();
            }
        });
        if (Object.keys(this.authorNotes).length > 0) {
            this.messages.push({ type: 'success', text: 'Author notes block found and removed from output.', icon: '&#9989;' });
        }
    }

    _processBody() {
        const elements = Array.from(this.doc.body.children);
        for (let i = 0; i < elements.length; i++) {
            const el = elements[i];
            if (!el) continue;

            // Rule: Blockquotes ( > text )
            if (el.tagName === 'P' && el.textContent.trim().startsWith('>')) {
                const blockquote = this.doc.createElement('blockquote');
                blockquote.innerHTML = `<p>${el.textContent.trim().substring(1).trim()}</p>`;
                el.replaceWith(blockquote);
                continue;
            }

            // Rule: FAQs (h2 with "FAQ")
            if (el.tagName === 'H2' && el.textContent.toLowerCase().includes('faq')) {
                const nextEl = elements[i + 1];
                if (nextEl && nextEl.tagName === 'UL') {
                    const faqContainer = this.doc.createElement('div');
                    faqContainer.className = 'faq-section';
                    
                    Array.from(nextEl.children).forEach(li => {
                        const parts = li.innerHTML.split(/<br\s*\/?>/); // Handles <br> and <br/>
                        if (parts.length >= 2) {
                            const details = this.doc.createElement('details');
                            const summary = this.doc.createElement('summary');
                            summary.innerHTML = parts[0].trim();
                            const p = this.doc.createElement('p');
                            p.innerHTML = parts.slice(1).join('<br>').trim();
                            details.appendChild(summary);
                            details.appendChild(p);
                            faqContainer.appendChild(details);
                        }
                    });
                    
                    if (faqContainer.children.length > 0) {
                        el.replaceWith(faqContainer);
                        nextEl.remove();
                        this.messages.push({ type: 'success', text: 'Interactive FAQ section created.', icon: '&#9989;' });
                        i++; // Skip the now-removed UL
                    }
                }
                continue;
            }
            
            // Rule: Image with Caption (img followed by italic p)
            if (el.tagName === 'P' && el.querySelector('img')) {
                const nextEl = elements[i+1];
                if (nextEl && nextEl.tagName === 'P' && (nextEl.querySelector('em') || /<i>.*<\/i>/.test(nextEl.innerHTML))) {
                    const figure = this.doc.createElement('figure');
                    const img = el.querySelector('img');
                    const figcaption = this.doc.createElement('figcaption');
                    figcaption.textContent = nextEl.textContent.trim();
                    
                    figure.appendChild(img.cloneNode(true));
                    figure.appendChild(figcaption);
                    
                    el.replaceWith(figure);
                    nextEl.remove();
                    this.messages.push({ type: 'success', text: 'Figure with caption created.', icon: '&#9989;' });
                    i++;
                }
            }
        }
    }

    _cleanupHtml() {
        // Remove empty anchor tags left by Mammoth
        this.doc.querySelectorAll('a').forEach(a => {
            if (!a.hasAttribute('href') && a.textContent.trim() === '' && a.children.length === 0) {
                a.remove();
            }
        });
    }

    _buildFinalHtml() {
        const title = this.metadata['title'] ? `${this.metadata['title']} - ${this.siteName}` : `${this.siteName} Document`;
        const description = this.metadata['description'] || 'A document converted from DOCX.';
        const slug = this._slugify(this.metadata['title'] || 'doc');
        const canonicalUrl = this.metadata['canonical'] || `https://examvest.com/blog/${slug}`;
        const ogImage = this.metadata['og-image'] || `https://placehold.co/1200x630/1a3a2f/ffffff?text=${encodeURIComponent(this.metadata['title'] || 'Examvest')}`;

        const bodyContent = this.doc.body.innerHTML;

        return `<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title}</title>
    <meta name="description" content="${description}">
    <link rel="canonical" href="${canonicalUrl}" />
    <meta property="og:title" content="${title}" />
    <meta property="og:description" content="${description}" />
    <meta property="og:type" content="article" />
    <meta property="og:url" content="${canonicalUrl}" />
    <meta property="og:image" content="${ogImage}" />
    <meta property="og:site_name" content="${this.siteName}" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="${title}" />
    <meta name="twitter:description" content="${description}" />
    <meta name="twitter:image" content="${ogImage}" />

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Lora:ital,wght@0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="scroll-progress-bar-container">
        <div class="scroll-progress-bar" id="scroll-progress"></div>
    </div>
    <header class="page-header">
      <h2 class="logo-title">${this.siteName}</h2>
      <nav id="nav-links">
        <a href="/">Home</a>
        <a href="/Course">Courses</a>
        <a href="/Tool">Tools</a>
        <a href="/games">Games</a>
        <a href="/blog">blogs</a>
      </nav>
      <button id="hamburger-btn" aria-label="Toggle menu">
        <span class="bar"></span><span class="bar"></span><span class="bar"></span>
      </button>
    </header>
    <main>
        <article class="blog-post-container">
            <h1>${this.metadata['title'] || 'Converted Document'}</h1>
            ${bodyContent}

            <section class="related-posts-section">
                <h2>Further Reading</h2>
                <div id="related-posts-container" class="related-posts-container">
                    </div>
            </section>
            </article>
    </main>
    </main>
    <script src="script.js"></script>
</body>
</html>`;
    }
    
    _slugify(text) {
        if (!text) return '';
        return text.toString().toLowerCase()
            .replace(/\s+/g, '-')
            .replace(/[^\w\-]+/g, '')
            .replace(/\-\-+/g, '-')
            .replace(/^-+/, '')
            .replace(/-+$/, '');
    }
}

// --- Content for Downloads & Modal ---

function getBlogCssContent() {
    return `
:root {
    --bg-paper: #f8f9fa;
    --card-bg: #ffffff;
    --text-main: #1a3a2f;
    --text-body: #343a40;
    --text-muted: #6c757d;
    --headline-bg: #eef3f1;
    --accent-color: #8c6239;
    --border-color: #dee2e6;
}
html { scroll-behavior: smooth; }
body { margin: 0; font-family: 'Inter', sans-serif; background: var(--bg-paper); color: var(--text-body); line-height: 1.8; }
h1, h2, h3, h4 { font-family: 'Lora', serif; color: var(--text-main); margin-top: 2em; margin-bottom: 1em; line-height: 1.3; }
h1 { font-size: 2.8rem; font-weight: 700; }
h2 { font-size: 2.2rem; font-weight: 600; border-bottom: 2px solid var(--headline-bg); padding-bottom: 0.3em; }
h3 { font-size: 1.6rem; }
p, ul, ol, table { margin-bottom: 1.5rem; font-size: 1.1rem; }
a { color: var(--accent-color); text-decoration: none; font-weight: 500; }
a:hover { text-decoration: underline; }
strong { color: var(--text-main); }
img { max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }

.scroll-progress-bar-container { position: fixed; top: 0; left: 0; width: 100%; height: 5px; background: transparent; z-index: 1001; }
.scroll-progress-bar { height: 5px; background: var(--accent-color); width: 0%; will-change: width; }

.page-header { background: var(--text-main); color: white; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 1000; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }
.page-header .logo-title { margin: 0; font-size: 24px; color: white; font-family: 'Lora', serif; text-decoration: none; border-bottom: none; }
nav { display: flex; gap: 25px; }
nav a { color: white; text-decoration: none; font-size: 16px; padding-bottom: 5px; border-bottom: 2px solid transparent; transition: border-color 0.3s; }
nav a:hover { border-color: var(--accent-color); text-decoration: none; }
#hamburger-btn { display: none; background: none; border: none; cursor: pointer; padding: 0; z-index: 1001; }
#hamburger-btn .bar { display: block; width: 25px; height: 3px; margin: 5px auto; background-color: white; transition: all 0.3s ease-in-out; }

.blog-post-container { max-width: 800px; margin: 40px auto; padding: 40px 60px; background: var(--card-bg); box-shadow: 0 4px 20px rgba(0,0,0,0.07); border-radius: 8px; border-top: 5px solid var(--text-main); }
.blog-post-container h1:first-of-type { margin-top: 0; }

figure { margin: 2.5em 0; text-align: center; }
figcaption { color: var(--text-muted); font-size: 0.9em; margin-top: 10px; font-style: italic; }

blockquote { margin: 2em 0; padding: 1.5em 2em; background: var(--headline-bg); border-left: 5px solid var(--accent-color); font-style: italic; font-family: 'Lora', serif; font-size: 1.2rem; position: relative; }
blockquote p { margin: 0; }
blockquote::before { font-family: 'Lora', serif; content: "“"; position: absolute; left: 0.3em; top: 0; font-size: 4em; color: rgba(0,0,0,0.08); }

.faq-section details { border-bottom: 1px solid var(--border-color); padding: 1.5em 0; }
.faq-section summary { font-weight: 600; color: var(--text-main); font-size: 1.2rem; cursor: pointer; list-style: none; }
.faq-section summary::-webkit-details-marker { display: none; }
.faq-section details p { padding: 1em 0 0 0; margin-bottom: 0; font-size: 1rem; }

/* ADD THIS AT THE END OF THE CSS STRING */

/* --- Related Posts Section --- */
.related-posts-section {
    padding-top: 2em;
    margin-top: 3em;
    border-top: 2px solid var(--headline-bg);
}

.related-posts-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 25px;
}

.related-post-card {
    background: var(--card-bg);
    border-radius: 8px;
    overflow: hidden;
    text-decoration: none;
    color: var(--text-body);
    border: 1px solid var(--border-color);
    transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
}

.related-post-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.08);
}

.related-post-card img {
    width: 100%;
    height: 150px;
    object-fit: cover;
    border-radius: 0;
    border-bottom: 1px solid var(--border-color);
}

.related-post-card-content {
    padding: 15px;
}

.related-post-card-content h4 {
    margin: 0 0 10px 0;
    font-size: 1.1rem;
    line-height: 1.4;
    color: var(--text-main);
}

.related-post-card-content p {
    font-size: 0.9rem;
    margin: 0;
    line-height: 1.5;
}

@media (max-width: 768px) {
    h1 { font-size: 2.2rem; }
    h2 { font-size: 1.8rem; }
    .blog-post-container { padding: 25px 20px; margin: 20px 10px; }
    nav { display: none; position: absolute; top: 100%; left: 0; width: 100%; background: var(--text-main); flex-direction: column; padding: 0; gap: 0; }
    nav.active { display: flex; }
    nav a { text-align: center; padding: 15px 0; border-bottom: 1px solid #4a6a5f; }
    #hamburger-btn { display: block; }
    #hamburger-btn.active .bar:nth-child(2) { opacity: 0; }
    #hamburger-btn.active .bar:nth-child(1) { transform: translateY(8px) rotate(45deg); }
    #hamburger-btn.active .bar:nth-child(3) { transform: translateY(-8px) rotate(-45deg); }
}`;
}




// REPLACE your old getBlogJsContent function with this new one
function getBlogJsContent() {
    return `
document.addEventListener('DOMContentLoaded', () => {
    // Hamburger Menu Logic
    const hamburgerBtn = document.getElementById('hamburger-btn');
    const navLinks = document.getElementById('nav-links');
    if (hamburgerBtn && navLinks) {
        hamburgerBtn.addEventListener('click', () => {
            hamburgerBtn.classList.toggle('active');
            navLinks.classList.toggle('active');
        });
    }

    // Scroll Progress Bar Logic
    const scrollProgressBar = document.getElementById('scroll-progress');
    if (scrollProgressBar) {
        const updateProgressBar = () => {
            const scrollTotal = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            if (scrollTotal > 0) {
                const scrolled = (window.scrollY / scrollTotal) * 100;
                scrollProgressBar.style.width = \`\${scrolled}%\`;
            } else {
                scrollProgressBar.style.width = '0%';
            }
        };
        let ticking = false;
        window.addEventListener('scroll', () => {
            if (!ticking) {
                window.requestAnimationFrame(() => {
                    updateProgressBar();
                    ticking = false;
                });
                ticking = true;
            }
        });
        updateProgressBar();
    }
    
    // --- NEW: Function to load related posts ---
    async function loadRelatedPosts() {
        const container = document.getElementById('related-posts-container');
        if (!container) return;

        try {
            // Assumes blogs.json is in the same directory or accessible via this path
            const response = await fetch('blogs.json');
            if (!response.ok) throw new Error('Could not fetch blog data.');
            
            const data = await response.json();
            const allBlogs = data.blogs;
            
            const currentBlogTitle = document.querySelector('h1').textContent;
            const otherBlogs = allBlogs.filter(blog => blog.title !== currentBlogTitle);

            const shuffled = otherBlogs.sort(() => 0.5 - Math.random());
            const selectedBlogs = shuffled.slice(0, 3);

            if (selectedBlogs.length === 0) {
                container.innerHTML = "<p>No other posts to suggest.</p>";
                return;
            }

            selectedBlogs.forEach(blog => {
                const card = document.createElement('a');
                card.href = blog.link;
                card.className = 'related-post-card';
                card.innerHTML = \`
                    <img src="\${blog.image || 'https://placehold.co/400x200/eef3f1/1a3a2f?text=Blog'}" alt="\${blog.title}">
                    <div class="related-post-card-content">
                        <h4>\${blog.title}</h4>
                        <p>\${blog.content.substring(0, 80)}...</p>
                    </div>
                \`;
                container.appendChild(card);
            });

        } catch (error) {
            console.error("Failed to load related posts:", error);
            container.innerHTML = "<p>Could not load suggestions at this time.</p>";
        }
    }

    // Call the new function
    loadRelatedPosts();
});`;
}





function getConventionsContent() {
    return `
        <h2>How to Format Your DOCX</h2>
        <p>Follow these conventions in your Word document to enable the smart transformations.</p>
        
        <h3>1. Metadata Block (Required)</h3>
        <p>Start your document with a bulleted list. Each item must be in the format <code>key: value</code>. This is used for SEO and page titles.</p>
        <pre>
- title: My Awesome Blog Post
- description: A short, compelling description of the article.
- canonical: https://examvest.com/blog/my-awesome-blog-post
- og-image: https://link-to-my/social-image.jpg
        </pre>
        <p>Available keys: <code>title</code>, <code>description</code>, <code>canonical</code>, <code>og-image</code>.</p>

        <h3>2. Blockquotes</h3>
        <p>To create a blockquote, simply start a paragraph with the ">" character followed by a space.</p>
        <pre>> This will be turned into a beautiful blockquote.</pre>
        
        <h3>3. FAQs (Frequently Asked Questions)</h3>
        <p>To create an interactive FAQ section:</p>
        <ol>
            <li>Add a heading (Heading 2) that contains the word "FAQ".</li>
            <li>Immediately after, create a bulleted list.</li>
            <li>For each list item, write the <strong>question</strong>, then press <strong>Shift+Enter</strong> for a soft line break, then write the <strong>answer</strong>.</li>
        </ol>
        
        <h3>4. Image with Captions</h3>
        <p>To create an image with a caption below it:</p>
        <ol>
            <li>Insert your image into the document.</li>
            <li>On the very next line, write your caption text and make it <em>italic</em>.</li>
        </ol>

        <h3>5. Author Notes (Optional)</h3>
        <p>If you have notes for yourself at the end of the document (like keyword lists), the converter will automatically find and remove them from the final HTML. It recognizes lines starting with:</p>
        <ul>
            <li><code>Primary Keyword:</code></li>
            <li><code>LSI Keywords:</code></li>
            <li><code>Emotional Hooks Summary:</code></li>
            <li>And other common note formats.</li>
        </ul>
        
        <p>Any content that doesn't match these rules will be converted to standard HTML paragraphs, headings, and lists.</p>
    `;
}
